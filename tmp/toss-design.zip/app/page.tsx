'use client'

import { useState } from 'react'
import Header from '@/components/header'
import BalanceCard from '@/components/balance-card'
import QuickActions from '@/components/quick-actions'
import TransactionHistory from '@/components/transaction-history'
import Navigation from '@/components/navigation'

export default function Home() {
  const [activeTab, setActiveTab] = useState<'home' | 'send' | 'more'>('home')

  return (
    <div className="flex flex-col h-screen bg-background">
      <Header />
      
      <main className="flex-1 overflow-y-auto pb-20">
        {activeTab === 'home' && (
          <>
            <BalanceCard />
            <QuickActions />
            <TransactionHistory />
          </>
        )}
        
        {activeTab === 'send' && (
          <div className="p-4">
            <h2 className="text-xl font-bold mb-4 mt-4">송금하기</h2>
            <div className="bg-card rounded-lg p-4 border border-border">
              <p className="text-muted-foreground">송금 기능은 준비 중입니다.</p>
            </div>
          </div>
        )}
        
        {activeTab === 'more' && (
          <div className="p-4">
            <h2 className="text-xl font-bold mb-4 mt-4">더보기</h2>
            <div className="space-y-2">
              <button className="w-full bg-card border border-border rounded-lg p-4 text-left hover:bg-secondary transition">
                <p className="font-semibold">설정</p>
                <p className="text-sm text-muted-foreground">앱 설정 및 개인정보</p>
              </button>
              <button className="w-full bg-card border border-border rounded-lg p-4 text-left hover:bg-secondary transition">
                <p className="font-semibold">고객지원</p>
                <p className="text-sm text-muted-foreground">도움말 및 문의</p>
              </button>
              <button className="w-full bg-card border border-border rounded-lg p-4 text-left hover:bg-secondary transition">
                <p className="font-semibold">이벤트</p>
                <p className="text-sm text-muted-foreground">진행 중인 이벤트</p>
              </button>
            </div>
          </div>
        )}
      </main>

      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  )
}
