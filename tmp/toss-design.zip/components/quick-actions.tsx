export default function QuickActions() {
  const actions = [
    {
      id: 1,
      label: '송금',
      icon: '↗️',
      color: 'from-blue-400 to-blue-600',
    },
    {
      id: 2,
      label: '결제',
      icon: '💳',
      color: 'from-green-400 to-green-600',
    },
    {
      id: 3,
      label: '충전',
      icon: '⬆️',
      color: 'from-purple-400 to-purple-600',
    },
    {
      id: 4,
      label: '출금',
      icon: '⬇️',
      color: 'from-orange-400 to-orange-600',
    },
  ]

  return (
    <div className="px-4 py-4 border-b border-border">
      <div className="grid grid-cols-4 gap-3">
        {actions.map((action) => (
          <button
            key={action.id}
            className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-secondary transition active:scale-95"
          >
            <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${action.color} flex items-center justify-center text-xl shadow-md`}>
              {action.icon}
            </div>
            <span className="text-xs font-semibold text-foreground text-center">
              {action.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  )
}
