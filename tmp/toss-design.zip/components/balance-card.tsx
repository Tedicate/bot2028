'use client'

import { useState } from 'react'

export default function BalanceCard() {
  const [showBalance, setShowBalance] = useState(true)

  return (
    <div className="px-4 py-6 space-y-4">
      <div className="bg-gradient-to-br from-primary to-blue-600 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-sm font-semibold opacity-80">총 자산</h2>
          <button
            onClick={() => setShowBalance(!showBalance)}
            className="text-white hover:opacity-75 transition"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d={showBalance ? 'M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-4.803c1.079-1.850 2.947-2.645 4.82-2.645.522 0 1.042.052 1.556.15a6 6 0 017.666 6.012A6.002 6.002 0 0112 15c-1.657 0-3.157-.671-4.243-1.757L8 12m6 0h.01M20.25 5.75l-1.414 1.414M5.75 5.75l1.414 1.414' : 'M15 12a3 3 0 11-6 0 3 3 0 016 0z'}
              />
            </svg>
          </button>
        </div>

        <div className="mb-8">
          {showBalance ? (
            <div className="text-4xl font-bold">
              ₩{(1234567).toLocaleString('ko-KR')}
            </div>
          ) : (
            <div className="text-4xl font-bold">••••••••</div>
          )}
          <p className="text-sm opacity-80 mt-2">예치금 포함</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/20 rounded-lg p-3">
            <p className="text-xs opacity-80 mb-1">입금</p>
            <p className="text-lg font-semibold">₩56,000</p>
          </div>
          <div className="bg-white/20 rounded-lg p-3">
            <p className="text-xs opacity-80 mb-1">출금</p>
            <p className="text-lg font-semibold">₩12,000</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">환율</p>
          <p className="font-semibold text-sm">1,296.50</p>
          <p className="text-xs text-accent">+2.1%</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">적금</p>
          <p className="font-semibold text-sm">₩450K</p>
          <p className="text-xs text-accent">+₩12K</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">투자</p>
          <p className="font-semibold text-sm">₩890K</p>
          <p className="text-xs text-accent">+8.5%</p>
        </div>
      </div>
    </div>
  )
}
