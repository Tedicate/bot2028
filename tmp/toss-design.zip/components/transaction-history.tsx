export default function TransactionHistory() {
  const transactions = [
    {
      id: 1,
      title: '우버 이츠',
      category: '음식',
      amount: '-₩18,500',
      time: '오늘 18:45',
      icon: '🍔',
      type: 'expense',
    },
    {
      id: 2,
      title: '급여',
      category: '입금',
      amount: '+₩3,500,000',
      time: '오늘 09:00',
      icon: '💰',
      type: 'income',
    },
    {
      id: 3,
      title: 'GS25',
      category: '편의점',
      amount: '-₩12,300',
      time: '어제 21:15',
      icon: '🏪',
      type: 'expense',
    },
    {
      id: 4,
      title: 'Netflix',
      category: '구독',
      amount: '-₩14,900',
      time: '3월 1일',
      icon: '🎬',
      type: 'expense',
    },
    {
      id: 5,
      title: '국민은행 이체',
      category: '이체',
      amount: '-₩500,000',
      time: '2월 28일',
      icon: '🏦',
      type: 'expense',
    },
    {
      id: 6,
      title: '스타벅스',
      category: '카페',
      amount: '-₩6,500',
      time: '2월 27일',
      icon: '☕',
      type: 'expense',
    },
  ]

  return (
    <div className="px-4 py-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold">거래 내역</h2>
        <button className="text-sm text-primary hover:underline">
          더보기
        </button>
      </div>

      <div className="space-y-2">
        {transactions.map((transaction) => (
          <button
            key={transaction.id}
            className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-secondary transition active:scale-98"
          >
            <div className="flex items-center gap-3 flex-1">
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-xl flex-shrink-0">
                {transaction.icon}
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground text-sm">
                  {transaction.title}
                </p>
                <div className="flex items-center gap-2">
                  <p className="text-xs text-muted-foreground">
                    {transaction.category}
                  </p>
                  <span className="text-xs text-muted-foreground">•</span>
                  <p className="text-xs text-muted-foreground">
                    {transaction.time}
                  </p>
                </div>
              </div>
            </div>
            <div className={`font-semibold text-sm ${
              transaction.type === 'income' ? 'text-accent' : 'text-foreground'
            }`}>
              {transaction.amount}
            </div>
          </button>
        ))}
      </div>

      <button className="w-full mt-4 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition active:scale-95">
        거래 내역 전체 보기
      </button>
    </div>
  )
}
